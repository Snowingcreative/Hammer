<h1 align="left">Hey 👋 What's up?</h1>

###

<p align="left">My name is Jacob and I'm a student, from denmark</p>

###

<h2 align="left">About me</h2>

###

<p align="left">📚 I'm currently learning python...<br>🎯 Goals: want to be a fullstack developer</p>

###

<h2 align="left">I code with</h2>

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="30" alt="python logo"  />
  <img width="12" />
</div>

###
